export default function TicketPage() {
  return <section></section>;
}
