export const convertions = [
  {
    name: "BlockB",
    value: 3260,
  },
  {
    name: "BlockA",
    value: 12320,
  },
  {
    name: "BlockC",
    value: 1320,
  },
  {
    name: "BlockD",
    value: 320,
  },
];